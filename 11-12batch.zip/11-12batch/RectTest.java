class Rectangle
{
	//attributes 	
	int l,b;
	//behavior
	public void setDimension(int x,int y)
	{
		l=x;
		b=y;
	}
	public void display()
	{
		System.out.println("l="+l);
		System.out.println("b="+b);
	}
	public int area()
	{
		return l*b;
	}
}
class RectTest
{
	public static void main(String[] arr)
	{
		Rectangle r=new Rectangle();
		r.setDimension(10,20);
		r.display();
		System.out.println("area="+r.area());
	}
}