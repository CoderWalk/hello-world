class First1
{
	static{
		main();
	}
	public static void main(String[] arr)
	{
	}
}
