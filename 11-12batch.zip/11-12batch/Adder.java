class Adder
{
	public static void main(String[] arr)
	{
		int a=10,b=20,c;
		c=a+b;
		//System.out.println(c);
		//System.out.println("sum="+c);
		System.out.println("sum of "+a+" & "+b+" is "+c);
	}
}
