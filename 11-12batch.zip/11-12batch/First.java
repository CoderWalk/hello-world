class First
{
	public static void main(String[] arr)
	{
		System.out.println("Hello World");
	}
}
