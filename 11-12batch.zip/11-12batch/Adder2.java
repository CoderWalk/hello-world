import java.util.*;
class Adder2
{
	public static void main(String[] arr)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter name");
		String name=sc.nextLine();
		System.out.println(name);
	}
}
