import java.util.*;
class Adder1
{
	public static void main(String[] arr)
	{
		int a,b,c;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter two no");
		a=sc.nextInt();
		b=sc.nextInt();
		c=a+b;
		//System.out.println(c);
		//System.out.println("sum="+c);
		System.out.println("sum of "+a+" & "+b+" is "+c);
	}
}
