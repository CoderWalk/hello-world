import java.util.*;
class ArrayDemo
{
	public static void main(String[] arr)
	{
		int[] a=new int[5];
		int i;
		Scanner sc=new Scanner(System.in);
		for(i=0;i<=5;i++)
		{
			System.out.println("enter no");
			a[i]=sc.nextInt();
		}
		for(i=0;i<5;i++)
		{
			System.out.print(a[i]+" ");
		}
	}
}