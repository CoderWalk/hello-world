package mypack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


//@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			String name=request.getParameter("t1");
			String pass=request.getParameter("t2");
			//obtain ref of servletconfig
			ServletConfig config=getServletConfig();
			//obtain servletcontext from servletconfig
			ServletContext ctx=config.getServletContext();
			String a=ctx.getInitParameter("dclass");
			String b=ctx.getInitParameter("conurl");
			String c=ctx.getInitParameter("user");
			String d=ctx.getInitParameter("password");
			System.out.println(a+" "+b+" "+c+" "+d);
			try {
				Class.forName(a);
				Connection con=DriverManager.getConnection(b,c,d);
				PreparedStatement psmt=con.prepareStatement("select * from user where name=? and password=?");
				psmt.setString(1, name);
				psmt.setString(2, pass);
				ResultSet rs=psmt.executeQuery();
				RequestDispatcher rd=null;
				if(rs.next())
				{
					String user_role=rs.getString(3);
					System.out.println("user="+user_role);
					request.setAttribute("urole", user_role);
					rd=request.getRequestDispatcher("/welcome");
					rd.forward(request,response);
				}
				else
				{
					out.println("incorrect username & password try again");
					rd=request.getRequestDispatcher("index.html");
					rd.include(request, response);
				}
				con.close();
			}catch(Exception e)
			{
				System.out.println(e);
			}
		
	}

}
