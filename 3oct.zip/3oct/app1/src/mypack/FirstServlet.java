package mypack;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet("/FirstServlet")
public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//obtain the ref of ServletConfig
		ServletConfig config=getServletConfig();
		//obtain servletcontxt from servletconfig
		ServletContext ctx1=config.getServletContext();
		//obtain servletcontext of app2 from servletcontext of app1
		ServletContext ctx2=ctx1.getContext("/app2");
		System.out.println("ctx2="+ctx2);
		if(ctx2!=null)
		{
			RequestDispatcher rd=ctx2.getRequestDispatcher("/second");
			rd.forward(request, response);
		}
		else
		{
			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			out.println("Either app2 is not deployed on the server");
			out.println("or server is not configured for cross-context request");
		}
		
	}

}
