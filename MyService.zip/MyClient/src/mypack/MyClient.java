package mypack;

import java.net.URL;
import java.util.*;

import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;

public class MyClient {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter first no");
		int a=sc.nextInt();
		System.out.println("enter Second no");
		int b=sc.nextInt();
		sc.close();
		try{
			XmlRpcClient client=new XmlRpcClient();
			XmlRpcClientConfigImpl config=new XmlRpcClientConfigImpl();
			config.setServerURL
			(new URL("http://localhost:7070/MyService/service"));
			client.setConfig(config);
			Object[] param=new Object[2];
			param[0]=new Integer(a);
			param[1]=new Integer(b);
			Object result=client.execute("adderSubtractor.subtract",param);
			System.out.println("result="+result);
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
