package mypack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet
 */
//@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try{
			String name=request.getParameter("t1");
			String mail=request.getParameter("t2");
			String pass=request.getParameter("t3");
			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
			PreparedStatement psmt=con.prepareStatement("insert into user9 values(?,?,?)");
			psmt.setString(1, name);
			psmt.setString(2, mail);
			psmt.setString(3, pass);
			int a=psmt.executeUpdate();
			if(a>0)
				out.println("successfully registered");
			else
				out.println("registration failed");
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
