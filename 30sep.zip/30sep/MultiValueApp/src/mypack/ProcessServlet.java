package mypack;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


//@WebServlet("/ProcessServlet")
public class ProcessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String name=request.getParameter("t1");
		String mail=request.getParameter("t2");
		String[] courses=request.getParameterValues("course");
		out.println("Welcome: "+name);
		out.println("<br>u r intrested in following course:");
		for(String c: courses)
		{
			out.println(c+"<br>");
		}
		out.println("our course counsellor will contact u soon on ur mailid: "+mail);
	}

}
