class Test1
{
	public static void main(String[] arr)
	{
		float a=12.50;
		System.out.println(a);
	}
}

/*what would be the output:
a- 12.50
b- 12.500000
c- compilation error
d- dont know

Solution: As we know floating point number has 6 places precision after decimal point so may be we can guess the output b option(12.500000) but it again shows a compilation error like found double required float the reason is we consdier the value is float but java is considering it like double but question occurs why it is double not float lets consider a scenario if we have to arrange a batch of students max 10 so we need 10 chairs for them but for all batches no of students may vary some contains max 10 & some contains even 5 or 6 or 8 so in or class room we have to need 10 chairs always so that 10 , 8 , 5 ,6 students can be placed easily similarly double have 8byte size & float has 4byte size & this value(12.50) is not a float or not a double it is a constant value of floating point type & floating point contains two type of value float & double so java consdier it as double by default so maximum data can be stored in it we have three ways to solve this type of problem:
1: put f in suffix after the value like:
	float a=12.50f; // now this is float value & stored in a float var

2: type cast the value to double:
	syntax is:
		(type)expression
Type Casting: It is the process to convert one data type into another it can be of two types a- down casting b-up casting
In upcasting lower type values auto upgrade in upper type vlaues i.e: 
	int a=10;
	long b=a;
here a is a int value which can easily be stored in long value .

down casting we have to to it manually with given syntax
	float a=(float)12.50;
now this double value is first cast into float value & then store in float var.

3: we can also change left side var to double i.e:

	double a=12.50 

*/