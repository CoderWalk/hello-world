class Test
{
	public static void main(String[] arr)
	{
		int a;
		System.out.println(a);
	}
}

what would be the output:
a- 0
b- 0.0
c- compilation error
d- dont know

Solution: As we know in java each data_type has its own default value like int 0 floating point o.o object null boolean false so according to this concepts the output should be a means 0 coz we dont provide any value so it consider its default value 0 but the program will show compilation error coz the above mentioned concept is partially true yes java has the concepts of default value but only for instance or static variables the variable which are declared inside class & outside any method but in our case this a var is declared inside main() method so it is consider it local var so local var are those var which are declared inside any method or in a block so it does not have any default value & we dont set any value in it so complier will show an error like var a might not have been initialized.