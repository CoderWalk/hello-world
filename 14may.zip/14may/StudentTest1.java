import java.util.*;
class Student
{
	int rno;
	String name;
	int fees;
	public void setData()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter data");
		rno=sc.nextInt();
		name=sc.next();
		fees=sc.nextInt();
	}
	public void showData()
	{
		System.out.println("rno="+rno);
		System.out.println("name="+name);
		System.out.println("fees="+fees);
		System.out.println("----------------------");
	}
}
class StudentTest1
{
	public static void main(String[] arr)
	{
		Student[] s=new Student[3];//array of Student type ref_var
		int i;
		for(i=0;i<3;i++)
		{
			s[i]=new Student();
			s[i].setData();
		}
		for(i=0;i<3;i++)
		{
			s[i].showData();
		}
	}
}
