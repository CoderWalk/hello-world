package mypack;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.DispatcherType;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;


@WebFilter(urlPatterns="/direct",
			dispatcherTypes= {DispatcherType.FORWARD,DispatcherType.REQUEST})
public class MyFilter implements Filter {

	FilterConfig config;
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
		config=fConfig;
	}

  	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		System.out.println("filter is invoked");
		ServletContext ctx=config.getServletContext();
		Integer hc=(Integer)ctx.getAttribute("hitcount");
		hc+=1;
		ctx.setAttribute("hitcount", hc);
		chain.doFilter(request, response);
		System.out.println("control back to filter");
	}

	public void destroy() {
		// TODO Auto-generated method stub
	}

}
