package mypack;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class MyListener implements ServletContextListener {

	ServletContext ctx;
    public void contextDestroyed(ServletContextEvent sce)  { 
         // TODO Auto-generated method stub
    }

	public void contextInitialized(ServletContextEvent sce)  { 
         // TODO Auto-generated method stub
		ctx=sce.getServletContext();
		ctx.setAttribute("hitcount", 0);
		System.out.println("hit count set to zero");
    }
	
}
