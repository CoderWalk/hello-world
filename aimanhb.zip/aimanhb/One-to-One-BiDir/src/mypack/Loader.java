package mypack;

import java.util.Scanner;

import org.hibernate.Session;

public class Loader {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter country id");
		int cid=sc.nextInt();
		Session session=MyFactory.getSession();
		Country c=(Country)session.get(Country.class,cid);
		System.out.println("country name="+c.getName());
		HeadOfState ho=c.getHos();
		System.out.println(ho.getName()+" "+ho.getTitle());
		System.out.println("-----------------------------");
		System.out.println("enter headofstate id");
		int hid=sc.nextInt();
		HeadOfState h=(HeadOfState)session.get(HeadOfState.class, hid);
		System.out.println(h.getName()+" "+h.getTitle());
		Country co=h.getCountry();
		System.out.println("country name="+co.getName());
		session.close();
		
	}

}
