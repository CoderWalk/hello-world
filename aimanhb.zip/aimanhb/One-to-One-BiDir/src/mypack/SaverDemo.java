package mypack;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class SaverDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("saving country obj...");
		HeadOfState hs1=new HeadOfState("R.N.Kovind", "president");
		HeadOfState hs2=new HeadOfState("Elizabeth II", "queen");
		Country c1=new Country("India", hs1);
		Country c2=new Country("UK", hs2);
		Session session=MyFactory.getSession();
		Transaction tx=session.beginTransaction();
		session.save(c1);
		session.save(c2);
		tx.commit();
		session.close();
		System.out.println("successfully saved...");
	}

}
