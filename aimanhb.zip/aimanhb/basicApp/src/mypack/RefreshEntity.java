package mypack;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class RefreshEntity {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("main thread started,load emp obj with id 4");
		Session ses=MyFactory.getSession();
		Emp e=(Emp)ses.get(Emp.class,4);
		System.out.println("creating a new thread to update emp state with id 4");
		Thread t=new Thread()//anonymous inner class
		{
			public void run()
			{
				System.out.println("child thread started");
				Session session=MyFactory.getSession();
				Emp r=(Emp)session.get(Emp.class, 4);
				Transaction tx=session.beginTransaction();
				r.setName("aaa");
				r.setJob("bbb");
				r.setSalary(1234);
				tx.commit();
				session.close();
			}
		};//anonymous inner class finish
		System.out.println("starting a child thread to update state of an emp");
		t.start();
		try {
			Thread.sleep(2000);
		}catch(Exception ex)
		{
			System.out.println(ex);
		}
		ses.refresh(e);
		System.out.println("state of an emp");
		System.out.println(e.getId()+" "+e.getName()+" "+e.getJob()+" "+e.getSalary());
	}

}
