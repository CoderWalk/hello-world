package mypack;

import java.util.Scanner;

import org.hibernate.Session;

public class EagerLoading {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id to load emp obj...");
		int id=sc.nextInt();
		Session ses=MyFactory.getSession();
		Emp e=(Emp)ses.get(Emp.class, id);
		System.out.println("entity loaded, session closed");
		ses.close();
		System.out.println("state of an entity");
		System.out.println(e.getId()+" "+e.getName()+" "+e.getJob()+" "+e.getSalary());
		System.out.println("successfully loaded...");
	}

}
