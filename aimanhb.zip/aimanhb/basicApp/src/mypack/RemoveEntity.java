package mypack;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class RemoveEntity {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id to delete emp");
		int id=sc.nextInt();
		Session ses=MyFactory.getSession();
		Emp e=(Emp)ses.get(Emp.class,id);
		Transaction tx=ses.beginTransaction();
		ses.delete(e);
		tx.commit();
		ses.close();
		System.out.println("successfully deleted...");
	}

}
