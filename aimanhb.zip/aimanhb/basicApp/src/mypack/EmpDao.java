package mypack;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class EmpDao {

	public Emp getById(int id)
	{
		Session ses=MyFactory.getSession();
		Emp e=(Emp)ses.get(Emp.class, id);
		ses.close();
		return e;
	}
	public void updater(Emp e)
	{
		Session ses=MyFactory.getSession();
		Transaction tx=ses.beginTransaction();
		ses.merge(e);
		tx.commit();
		ses.close();
	}
}
