package mypack;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class ConnectedUpdater {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id to load emp");
		int id=sc.nextInt();
		Session ses=MyFactory.getSession();
		Emp e=(Emp)ses.get(Emp.class, id);
		System.out.println("emp loaded");
		System.out.println(e.getId()+" "+e.getName()+
				" "+e.getJob()+" "+e.getSalary());
		System.out.println("enter new name");
		String name=sc.next();
		System.out.println("enter new job");
		String job=sc.next();
		System.out.println("enter new salary");
		int sal=sc.nextInt();
		Transaction tx=ses.beginTransaction();
		e.setName(name);
		e.setJob(job);
		e.setSalary(sal);
		tx.commit();
		ses.close();
		System.out.println("successfully updated");
	}

}
