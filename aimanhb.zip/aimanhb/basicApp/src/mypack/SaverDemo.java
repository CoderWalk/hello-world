package mypack;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class SaverDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("creating two emp obj");
		//Emp e=new Emp("danish", "developer", 45000);
		//Emp f=new Emp("aiman","DBA",67000);
		Emp e=new Emp("amit", "ios-devp", 75000);
		Emp f=new Emp("mohit","QA",37000);
		System.out.println("obtain session form myfactory");
		Session s=MyFactory.getSession();
		System.out.println("obtain a transaction");
		Transaction tx=s.beginTransaction();
		s.save(e);
		s.save(f);
		tx.commit();
		s.close();
		System.out.println("successfully saved...");
	}

}
