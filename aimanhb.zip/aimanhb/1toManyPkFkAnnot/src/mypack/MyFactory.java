package mypack;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class MyFactory {

	private static SessionFactory factory;
	static {
		AnnotationConfiguration cfg=new AnnotationConfiguration().configure();
		factory=cfg.buildSessionFactory();
	}
	public static Session getSession()
	{
		return factory.openSession();
	}
}
