package mypack;
import java.util.*;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class SaverDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("saving trainer obj...");
		HashSet<Batch> s1=new HashSet<Batch>();
		s1.add(new Batch("weekend", "10-12", "java"));
		s1.add(new Batch("weekdays", "2-4", "python"));
		s1.add(new Batch("weekend", "5-7", "flask"));
	
		HashSet<Batch> s2=new HashSet<Batch>();
		s2.add(new Batch("weekend", "9-11", "django"));
		s2.add(new Batch("weekdays", "12-2", "hibernate"));
		
		Trainer t1=new Trainer("rahul", s1);
		Trainer t2=new Trainer("aiman", s2);
		
		Session session=MyFactory.getSession();
		Transaction tx=session.beginTransaction();
		session.save(t1);
		session.save(t2);
		tx.commit();
		session.close();
		System.out.println("successfully saved...");
	}

}
