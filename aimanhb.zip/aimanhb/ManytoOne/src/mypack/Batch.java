package mypack;

public class Batch {

	//state
	private int id;
	private String mode,slot,course;
	//relation
	Trainer trainer;
	public Batch() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Batch(String mode, String slot, String course, Trainer trainer) {
		super();
		this.mode = mode;
		this.slot = slot;
		this.course = course;
		this.trainer = trainer;
	}

	/*public Batch(String mode, String slot, String course) {
		super();
		this.mode = mode;
		this.slot = slot;
		this.course = course;
	}*/
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getSlot() {
		return slot;
	}
	public void setSlot(String slot) {
		this.slot = slot;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}

	public Trainer getTrainer() {
		return trainer;
	}

	public void setTrainer(Trainer trainer) {
		this.trainer = trainer;
	}
	
}
