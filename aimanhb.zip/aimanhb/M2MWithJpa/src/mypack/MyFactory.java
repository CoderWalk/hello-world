package mypack;

import javax.persistence.*;


public class MyFactory {

	private static EntityManagerFactory factory1;
	static
	{
		factory1=Persistence.createEntityManagerFactory("first");
	}
	public static EntityManager getEntityManager()
	{
		return factory1.createEntityManager();
	}
}
