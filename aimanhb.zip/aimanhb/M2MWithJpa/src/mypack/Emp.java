package mypack;
import java.util.*;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="emp")
public class Emp {

	//state
	@Id
	@GeneratedValue
	private int id;
	private String name,job;
	private int salary;
	//relation
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="emp_previlige",
			joinColumns=@JoinColumn(name="eid"),
			inverseJoinColumns=@JoinColumn(name="pid")
	)
	Set<Previlige> previliges;
	public Emp() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Emp(String name, String job, int salary, Set<Previlige> previliges) {
		super();
		this.name = name;
		this.job = job;
		this.salary = salary;
		this.previliges = previliges;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public Set<Previlige> getPreviliges() {
		return previliges;
	}
	public void setPreviliges(Set<Previlige> previliges) {
		this.previliges = previliges;
	}
	
	
}
