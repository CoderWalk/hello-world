package mypack;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class SaverDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("creating person family obj...");
		Person p=new Person("aiman");
		p.setId(101);
		Emp e=new Emp("zaid","developer",50000);
		e.setId(102);
		Student st=new Student("akhil", "java", 8000);
		st.setId(103);
		System.out.println("obtain session form myfactory");
		Session s=MyFactory.getSession();
		System.out.println("obtain a transaction");
		Transaction tx=s.beginTransaction();
		s.save(p);
		s.save(e);
		s.save(st);
		tx.commit();
		s.close();
		System.out.println("successfully saved...");
	}

}
