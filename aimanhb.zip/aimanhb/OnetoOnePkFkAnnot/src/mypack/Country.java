package mypack;

import javax.persistence.*;


//owner entity
@Entity
@Table(name="countries")
public class Country {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String name;
	//relation 
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="hosid")
	private HeadOfState hos;
	
	public Country() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Country(String name, HeadOfState hos) {
		super();
		this.name = name;
		this.hos = hos;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public HeadOfState getHos() {
		return hos;
	}
	public void setHos(HeadOfState hos) {
		this.hos = hos;
	}
	 
}
