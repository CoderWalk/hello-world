package mypack;
import java.util.*;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class SaverDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("saving trainer obj...");
		Trainer t1=new Trainer("rahul");
		Trainer t2=new Trainer("aiman");
		
		Batch b1=new Batch("weekend", "10-12", "java",t1);
		Batch b2=new Batch("weekdays", "2-4", "python",t1);
		Batch b3=new Batch("weekend", "5-7", "flask",t1);
		HashSet<Batch> s1=new HashSet<Batch>();
		s1.add(b1);s1.add(b2);s1.add(b3);
		
		Batch b4=new Batch("weekend", "9-11", "django",t2);
		Batch b5=new Batch("weekdays", "12-2", "hibernate",t2);
		HashSet<Batch> s2=new HashSet<Batch>();
		s2.add(b4);s2.add(b5);
		
		Session session=MyFactory.getSession();
		Transaction tx=session.beginTransaction();
		session.save(b1);
		session.save(b2);
		session.save(b3);
		session.save(b4);
		session.save(b5);
		tx.commit();
		session.close();
		System.out.println("successfully saved...");
	}

}
