package mypack;

import java.util.*;

import org.hibernate.Query;
import org.hibernate.Session;

public class ConditionLoader {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Session session=MyFactory.getSession();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter emp count");
		int count=sc.nextInt();
		System.out.println("load those emp who avail "+count+" or more previliges");
		Query q=session.createQuery("from Emp e where size(e.previliges)>=? order by e.name asc");
		q.setInteger(0, count);
		List<Emp> list=q.list();
		for(Emp e: list)
			System.out.println(e.getId()+" "+e.getName()+" "+e.getJob()+" "+e.getSalary());
		
		session.close();
	}

}
