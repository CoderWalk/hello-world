package mypack;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

public class AllEmpLoader {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Session session=MyFactory.getSession();
		Query q=session.createQuery("from Emp e");
		List<Emp> list=q.list();
		System.out.println("following emp are loaded");
		for(Emp e : list)
			System.out.println(e.getId()+" "+e.getName()+
					" "+e.getJob()+" "+e.getSalary());
		session.close();
	}

}
