package mypack;

import java.util.*;

import org.hibernate.Query;
import org.hibernate.Session;

public class SingleFieldProjectionWithOrderby {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Session session=MyFactory.getSession();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter previlige count");
		int count=sc.nextInt();
		System.out.println("load those previliges who avail "+count+" or more employees");
		Query q=session.createQuery("select p.name from Previlige p where size(p.employees)>=:ecount order by p.cost asc");
		q.setInteger("ecount", count);
		List<String> list=q.list();
		for(String name: list)
			System.out.println(name);
		
		session.close();
	}

}
