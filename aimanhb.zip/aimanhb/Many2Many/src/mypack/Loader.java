package mypack;
import java.util.*;

import org.hibernate.Session;

public class Loader {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter emp id");
		Scanner sc=new Scanner(System.in);
		int eid=sc.nextInt();
		Session session=MyFactory.getSession();
		Emp e=(Emp)session.get(Emp.class,eid);
		System.out.println("details of emp...");
		System.out.println(e.getName()+" "+e.getJob()+" "+e.getSalary());
		Set<Previlige> pv=e.getPreviliges();
		System.out.println("previligies availed by emp");
		for(Previlige p: pv)
			System.out.println(p.getName()+" "+p.getCost());
		System.out.println("-----------------------------------");
		System.out.println("enter previlige id");
		int pid=sc.nextInt();
		Previlige pi=(Previlige)session.get(Previlige.class,pid);
		System.out.println("details of previliges");
		System.out.println(pi.getName()+" "+pi.getCost());
		Set<Emp> ep=pi.getEmployees();
		System.out.println("details of emp who availed these previliges");
		for(Emp q: ep)
			System.out.println(q.getName()+" "+q.getJob()+" "+q.getSalary());
		session.close();
	}

}
