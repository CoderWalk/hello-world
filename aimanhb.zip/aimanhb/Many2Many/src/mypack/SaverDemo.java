package mypack;
import java.util.*;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class SaverDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Previlige p1=new Previlige("car", 240000);
		Previlige p2=new Previlige("flat", 340000);
		Previlige p3=new Previlige("club-membership", 440000);
		
		Set<Previlige> s1=new HashSet<Previlige>();
		s1.add(p1);s1.add(p2);s1.add(p3);
		
		Set<Previlige> s2=new HashSet<Previlige>();
		s2.add(p1);s2.add(p2);
		
		Set<Previlige> s3=new HashSet<Previlige>();
		s3.add(p1);
		
		Emp e1=new Emp("rahul", "CEO", 250000, s1);
		Emp e2=new Emp("aiman", "CFO", 200000, s2);
		Emp e3=new Emp("danish", "Manager", 150000, s3);
		
		Session session=MyFactory.getSession();
		Transaction tx=session.beginTransaction();
		session.save(e1);
		session.save(e2);
		session.save(e3);
		tx.commit();
		session.close();
		System.out.println("successfully saved...");
	}

}
