package mypack;

import java.util.*;

import org.hibernate.Query;
import org.hibernate.Session;

public class MultiFieldProjection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Session session=MyFactory.getSession();
		Scanner sc=new Scanner(System.in);
		System.out.println(
				"Loading name & salary of all employees "
				+ "in asc order of salary...");
			Query q=session.createQuery(
	"select e.name, e.salary from Emp e order by e.salary desc");
			
			List<Object[]> list=q.list();
			System.out.println("following Emp are loaded:");
			for(Object[] a: list)
			{
				System.out.println(a[0]+"\t"+a[1]);
			}
		session.close();
	}

}
