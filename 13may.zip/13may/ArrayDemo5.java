import java.util.*;
class ArrayDemo5
{
	public static void main(String[] arr)
	{
		show(new String[]{"faheel","ameen","rahul"});	
	}	
	public static void show(String[] a)
	{
		//for(int i=0;i<a.length;i++)
		//System.out.println(a[i]);
		for(String data:a)//enhanced for loop
		System.out.println(data);
	}
}