import java.util.*;
class ArrayDemo
{
	public static void main(String[] arr)
	{
		Scanner sc=new Scanner(System.in);
		int[] a=new int[5];
		int i;
		for(i=0;i<=5;i++)
		{
			System.out.println("enter no");
			a[i]=sc.nextInt();
		}
		for(i=0;i<5;i++)
		{
			System.out.println(a[i]);
		}
	}	
}