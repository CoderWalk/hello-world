import java.util.*;
class ArrayDemo1
{
	public static void main(String[] arr)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter size of an array");
		int size=sc.nextInt();
		int[] a=new int[size];
		int i;
		for(i=0;i<size;i++)
		{
			System.out.println("enter no");
			a[i]=sc.nextInt();
		}
		for(i=0;i<size;i++)
		{
			System.out.println(a[i]);
		}
	}	
}