/*Question: can we write java prog without main method
Answer: solution yes we can write it inside static block in java each class implicitly have a static{} block which is execute by jre at the time of class loading so if we put any code inside it jre execute it at class loading time only & classes only loaded once in memeory so the first thing is executed by jre is static block after at class loading time after load class jre invokes main() so we can write our code inside static block{} it executes first.
This code work on till jdk 6 , jdk 7 onwards things changed u can not write any program without main method coz in newer version like enterprises application like spring-boot we need main method too.*/

class First2
{
	static{
		System.out.println("hello world");
		System.exit(0);//to quit our program from memory other wise jre thorws an exception coz after class loading it search main() which is unavailable in our code so just quit our prg so jre will not complain any thing.
	}
}