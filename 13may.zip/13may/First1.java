/*Question: can we overload main method in java:
Answer: solution we can overload main() in java as many main() we can create it just need to change arguments type, jre will invoke its own main() method first inside jre main specific method u can call ur own main() mehtod demonstrate in this prg*/

class First1
{
	public static void main(String[] arr)
	{
		System.out.println("hello world");
		main();
	}
	public static void main()
	{
		System.out.println("my custom main() invoked");
	}
}