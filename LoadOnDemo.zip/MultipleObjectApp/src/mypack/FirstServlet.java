package mypack;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


//@WebServlet("/FirstServlet")
public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	//this method is override by GenericServlet class
	@Override
	public void init() throws ServletException {
		//obtain the ref of servletconfig
		ServletConfig config=getServletConfig();
		//name of the servlet is obtained by servletconfig
		String name=config.getServletName();
		System.out.println(name+" servlet obj is created");
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println(getServletConfig().getServletName()+" is instantiated");
		
	}

}
