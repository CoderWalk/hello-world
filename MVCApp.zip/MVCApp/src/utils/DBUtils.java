package utils;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.*;
public class DBUtils {

	public static Connection con;
	public static Connection getConnection()throws Exception
	{
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","abc123");
		return con;
	}
}
