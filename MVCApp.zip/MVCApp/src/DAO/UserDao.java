package DAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.*;

import com.mysql.jdbc.ResultSet;

import model.User;
import utils.DBUtils;
public class UserDao {

	public String login(User u)throws Exception
	{
		Connection con=DBUtils.getConnection();
		PreparedStatement psmt=con.prepareStatement("select * from users where name=? and pass=?");
		psmt.setString(1,u.getName());
		psmt.setString(2,u.getPassword());
		ResultSet rs=(ResultSet) psmt.executeQuery();
		con.close();
		if(rs.next())
			return "success";
		else
			return "failure";
			
	}
}
