class AB
{
	int a,b;
	public AB()
	{
		this(10,20);
		System.out.println("zero arg const invoked");	
	}
	public AB(int a)
	{
		this(a,4);
		System.out.println("one arg const invoked");
	}
	public AB(int a,int b)
	{
		this.a=a;
		this.b=b;
		System.out.println("two arg const invoked");
	}
	public void show()
	{
		System.out.println(a+" "+b);
	}
}
class ThisDemo2
{
	public static void main(String[] arr)
	{
		AB x=new AB();
		x.show();
		AB y=new AB(2);
		y.show();
		AB z=new AB(100,200);
		z.show();
	}
} 