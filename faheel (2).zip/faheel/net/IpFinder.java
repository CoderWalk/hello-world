import java.net.*;
class IpFinder
{
	public static void main(String[] arr)
	{
		try{
			//InetAddress add=InetAddress.getLocalHost("localhost");
			InetAddress add=InetAddress.getByName("localhost");
			System.out.println("ip is: "+add.getHostAddress());
			System.out.println("machine name is: "+add.getHostName());
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}
}

