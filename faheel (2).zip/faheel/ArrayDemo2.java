class ArrayDemo2
{
	public static void main(String[] arr)
	{
		int[] a={1,2,3,4,5};
		int i;
		for(i=0;i<5;i++)
		{
			System.out.println(a[i]);
		}
	}	
}