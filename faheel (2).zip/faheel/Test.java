class Test
{
	public Test()
	{
		System.out.println("const invoked");
	}
	public static void main(String[] arr)
	{
		Test t=new Test();
	}
}