interface A
{
	default void display()
	{
		System.out.println("display from A");
	}
	
}
interface B
{
	default void display()
	{
		System.out.println("display from B");
	}
}
class C implements A,B
{
			
}
class DiamondDemo
{
	public static void main(String[] arr)
	{
		C x=new C();
		x.display();
	}
}