class Outer
{
	private int a;
	public Outer()
	{
		a=10;
	}
	public  void show()
	{
		System.out.println("a in outer="+a);
	}
	public int getA()//3
	{
		return a;
	}
	//inner class
	class Inner
	{
		int b;
		Outer ref;//1
		public Inner(int x)
		{
			b=x;
			ref=new Outer();//2
		}	
		public void display()
		{
			System.out.println("a in inner="+ref.getA());//4
			System.out.println("b="+b);	
		}
	}//inner finish
}
class InnerDemo3
{
	public static void main(String[] arr)
	{
		Outer x=new Outer();
		x.show();
		Outer.Inner y=x.new Inner(20);
		y.display();
	}
}