import java.util.*;
class ScannerDemo
{
	public static void main(String[] arr)
	{	
		Scanner sc=new Scanner(System.in);
		System.out.println("enter name");
		String name=sc.nextLine();	
		System.out.println("your name="+name);
	}		
}