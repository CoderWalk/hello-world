import java.io.*;
class SequenceDemo
{
	public static void main(String[] arr)
	{
		try{
			FileInputStream f1=new FileInputStream(arr[0]);
			FileInputStream f2=new FileInputStream(arr[1]);
			SequenceInputStream f=new SequenceInputStream(f1,f2);
			int ch;
			while(true)
			{
				ch=f.read();
				if(ch==-1)//eof
				{
					break;
				}
				System.out.print((char)ch);
			}
			f.close();	
		}catch(Exception e)
		{	
			System.out.println(e);	
		}
	}
}
