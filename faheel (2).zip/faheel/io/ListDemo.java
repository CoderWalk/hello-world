import java.io.*;
class ListDemo
{
	public static void main(String[] arr)
	{
		try{
		File f=new File(arr[0]);
		if(f.isFile())
		{
			System.out.println("it is not a dir");
		}
		else
		{
			String[] data=f.list();
			for(String s: data)
			System.out.println(s);
		}
		}catch(Exception e)
		{
			System.out.println(e);	
		}
	}
}