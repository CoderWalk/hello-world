import java.io.*;
class ReadDemo1
{
	public static void main(String[] arr)
	{
		try{
			BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream(arr[0])));
			while(true)
			{
				String data=br.readLine();
				if(data==null)
				{
					break;
				}
				System.out.println(data);
			}
				
		}catch(Exception e)
		{	
			System.out.println(e);	
		}
	}
}
