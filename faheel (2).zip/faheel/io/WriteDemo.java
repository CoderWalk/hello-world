import java.io.*;
class WriteDemo
{
	public static void main(String[] arr)
	{
		try{
		PrintWriter out=new PrintWriter(new FileOutputStream(arr[0]));
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		while(true)
		{
			System.out.println("enter data,end to finish");
			String data=br.readLine();
			if(data.equals("end"))
			{
				break;		
			}
			out.println(data);
		}
		out.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}
}