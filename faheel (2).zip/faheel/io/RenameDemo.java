import java.io.*;
class RenameDemo
{
	public static void main(String[] arr)
	{
		try{
		File f=new File(arr[0]);
		if(!f.exists())
		{
			System.out.println("not exists");
		}
		else
		{
			if(f.renameTo(new File(arr[1])))
			System.out.println("sucessfully renamed");
			else
			System.out.println("sorry can't be renamed");
		}
		}catch(Exception e)
		{
			System.out.println(e);	
		}
	}
}