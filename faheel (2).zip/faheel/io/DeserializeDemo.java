import java.io.*;
class DeserializeDemo
{
	public static void main(String[] arr)
	{		
		try{
		ObjectInputStream in=new ObjectInputStream(new FileInputStream("emp.ser"));
		Emp p=(Emp)in.readObject();
		Emp q=(Emp)in.readObject();
		System.out.println("following obj are deserialized successfully...");
		p.show();
		q.show();
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
