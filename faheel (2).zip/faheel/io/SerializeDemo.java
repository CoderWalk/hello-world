import java.io.*;
class Emp implements Serializable
{
	int id;
	transient int sal;
	String name;
	public Emp(int x,String y,int z)
	{
		id=x;
		name=y;
		sal=z;
	}
	public void show()
	{
		System.out.println(id+" "+name+" "+sal);
	}
}
class SerializeDemo
{
	public static void main(String[] arr)
	{		
		try{
		System.out.println("creating emp obj");
		Emp e=new Emp(101,"abc",10000);
		Emp f=new Emp(102,"xyz",12000);
		System.out.println("details of emp to be serialize");
		e.show();
		f.show();
		ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream("emp.ser"));
		out.writeObject(e);
		out.writeObject(f);
		Thread.sleep(2000);
		System.out.println("successfully serialized...");
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
