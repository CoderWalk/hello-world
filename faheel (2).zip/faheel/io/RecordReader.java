import java.io.*;
import java.util.*;
class RecordReader
{
	public static void main(String[] arr)
	{
		try{
		BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream("student.txt")));
		while(true)
		{
			String data=br.readLine();
			if(data==null)
			{
				break;		
			}
			show(data);
		}
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public static void show(String line)
	{
		StringTokenizer st=new StringTokenizer(line,",");
		while(st.hasMoreTokens())
		{
			System.out.println(st.nextToken()+" "+st.nextToken()+" "+st.nextToken());
		}
	}
}