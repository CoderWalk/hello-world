import java.io.*;
class ReadDemo
{
	public static void main(String[] arr)
	{
		try{
			FileInputStream f=new FileInputStream(arr[0]);
			int ch;
			while(true)
			{
				ch=f.read();
				if(ch==-1)//eof
				{
					break;
				}
				System.out.print((char)ch);
			}
			f.close();	
		}catch(Exception e)
		{	
			System.out.println(e);	
		}
	}
}
