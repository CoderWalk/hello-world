class OverloadDemo1
{
	static{
		show();
	}
	public static void main(String[] faheel)
	{
		System.out.println("hello world");
	}
	public static void show()
	{
		System.out.println("my show invoked");
	}
}