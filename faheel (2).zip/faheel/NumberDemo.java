interface Number
{
	public Number add(Number n1);
	public void show();
}
class Rational implements Number
{
	int p,q;
	public Rational(int p,int q)
	{
		this.p=p;
		this.q=q;
	}
	public void show()
	{
		System.out.println(p+"/"+q);
	}
	public Number add(Number n1)
	{
		Rational r=(Rational)n1;
		int x=r.p*this.q+r.q*this.p;
		int y=r.q*this.q;
		return new Rational(x,y);
	}
}
class Complex implements Number
{
	int x,y;
	public Complex(int x,int y)
	{
		this.x=x;
		this.y=y;
	}
	public void show()
	{
		System.out.println(x+"+"+y+"i");
	}
	public Number add(Number n1)
	{
		Complex c=(Complex)n1;
		int x=c.x+this.x;
		int y=c.y+this.y;
		return new Complex(x,y);
	}
}
class NumberDemo
{
	public static void main(String[] arr)
	{
		System.out.println("creating two number obj");
		//Number n1=new Rational(2,5);
		//Number n2=new Rational(4,8);
		Number n1=new Complex(2,5);
		Number n2=new Complex(4,8);
		System.out.println("their details");
		n1.show();
		n2.show();
		System.out.println("their sum: ");
		Number n3=n1.add(n2);
		n3.show();
	}
}