class BoxingDemo
{
	public static void main(String[] arr)
	{
		int a=10;
		Integer i=new Integer(a);//boxing
		System.out.println(i);
		System.out.println(i.intValue());
		int b=i;//unboxing
		System.out.println(b);
	}
}