import java.util.*;
class Bank
{
	private int acno;
	private String name;
	private int bal;
	Scanner sc=new Scanner(System.in);
	public void setData()
	{
		System.out.println("enter details");
		acno=sc.nextInt();
		name=sc.next();
		bal=sc.nextInt();
	}
	public void showData()
	{
		System.out.println(acno+" "+name+" "+bal);
	}
	public void withdraw()
	{
		System.out.println("enter amt to be withdraw");
		int amt=sc.nextInt();
		if(bal-amt>=1000)
		{
			bal=bal-amt;
			System.out.println("successfully withdrawled");
		}
		else
		{
			System.out.println("not enough bal");
		}
	}
	public void deposit()
	{
		System.out.println("enter amt to be deposit");
		int amt=sc.nextInt();
		bal=bal+amt;
		System.out.println("successfully deposited");
	}
	public int getacno()
	{
		return acno;
	}
}
class BankDemo
{
	public static void main(String[] arr)
	{
		Bank[] b=new Bank[3];
		int choice,n,f,i;
		Scanner sc=new Scanner(System.in);
		do{
		System.out.println("1:Add account\n2:Show Details\n3:Withdraw\n4:Deposit\n5:Exit\nenter u choice");
		choice=sc.nextInt();
		switch(choice)
		{
			case 1:
				for(i=0;i<3;i++)
				{
					b[i]=new Bank();
					b[i].setData();
				}
				break;
			case 2:
				for(i=0;i<3;i++)
				{
					b[i].showData();
				}
				break;
			case 3:
				f=0;
				System.out.println("enter acno to withdraw");
				n=sc.nextInt();
				for(i=0;i<3;i++)
				{
					if(n==b[i].getacno())
					{
						f=1;
						b[i].withdraw();
						break;
					}
				}
				if(f==0)
				{
				System.out.println("acno not found");
				}
				break;
			case 4:
				f=0;
				System.out.println("enter acno to deposit");
				n=sc.nextInt();
				for(i=0;i<3;i++)
				{
					if(n==b[i].getacno())
					{
						f=1;
						b[i].deposit();
						break;
					}
				}
				if(f==0)
				{
				System.out.println("acno not found");
				}
				break;
		}
		}while(choice!=5);
	}
}