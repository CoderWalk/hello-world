package Q4;
public class A
{
	protected void show()
	{
		System.out.println("show invoked");
	}
}