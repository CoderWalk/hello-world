class B extends A
{
	public void show()
	{
		System.out.println("from B");
	}
}
class BindingDemo
{
	public static void main(String[] arr)
	{
		A x=new A();
		B y=new B();
		A.invoke(x);
		A.invoke(y);
	}
}