class MyException extends Exception
{
	public MyException()
	{
		super();
	}
	public MyException(String m)
	{
		super(m);
	}	
		
}
class CustomDemo1
{
	public static void main(String[] arr)
	{
		try{
		System.out.println("throwing custom excp....");
		throw(new MyException());
		//throw(new MyException("my arg excp"));
		}catch(Exception e)
		{
			System.out.println(e.toString());
		}
	}
}