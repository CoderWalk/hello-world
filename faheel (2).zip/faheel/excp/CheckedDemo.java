import java.io.*;
class CheckedDemo
{
	public static void main(String[] arr)throws IOException
	{
		FileInputStream f=new FileInputStream("a.txt");
	}
}
