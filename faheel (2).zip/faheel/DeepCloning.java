class Course implements Cloneable
{
	String course;
	public Course(String s)
	{
		course=s;
	}
	public Object clone()throws CloneNotSupportedException
	{
		return super.clone();
	}
}
class Student implements Cloneable
{
	int rno;
	String name;	
	Course c;//has a relationship
	public Student(int x,String y,Course z)
	{
		rno=x;
		name=y;
		c=z;
	}
	public void show()
	{
		System.out.println(rno+" "+name+" "+c.course);
	}
	public Object clone()throws CloneNotSupportedException
	{	
		Student t=(Student)super.clone();
		t.c=(Course)t.c.clone();
		return t;
	}
}
class DeepCloning
{
	public static void main(String[] arr)throws CloneNotSupportedException
	{
		Course c=new Course("BCA");
		Student s=new Student(101,"abc",c);
		System.out.println("details of student obj to be clone");
		s.show();	
		Student temp=(Student)s.clone();
		System.out.println("-----------------------");
		System.out.println("details of cloned obj");
		temp.show();
		temp.c.course="MCA";
		System.out.println("course details after changes...");
		temp.show();
		s.show();
	}
}