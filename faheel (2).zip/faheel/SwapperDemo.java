class Swapper
{
	int a,b;
	public Swapper(int a,int b)
	{
		this.a=a;
		this.b=b;
		//return this;
	}
	public Swapper swap()
	{
		int temp;
		temp=a;
		a=b;
		b=temp;
		return this;//to facilitate method chaining
	}
	public Swapper show()
	{
		System.out.println(a+" "+b);
		return this;//to facilitate method chaining
	}
}
class SwapperDemo
{
	public static void main(String[] arr)
	{
		//conventional approach
		//Swapper s=new Swapper(10,20);
		/*s.show();
		s.swap();
		s.show();*/
		//method chaining approach
		//s.show().swap().show();
		//constructor call & method chaining together
		new Swapper(10,20).show().swap().show();
	}
}