interface A
{
	default void display()
	{
		System.out.println("display from A");
	}
	
}
interface B
{
	default void display()
	{
		System.out.println("display from B");
	}
}
class C implements A,B
{
	public void display()
	{
		A.super.display();
		B.super.display();
	}			
}
class DiamondDemo1
{
	public static void main(String[] arr)
	{
		C x=new C();
		x.display();
	}
}