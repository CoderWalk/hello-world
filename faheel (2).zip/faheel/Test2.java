class Test
{
	int a=10;
	public static void main(String[] arr)
	{
		System.out.println(a);
	}
}