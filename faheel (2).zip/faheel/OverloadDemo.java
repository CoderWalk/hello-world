class OverloadDemo
{
	public static void main(String[] faheel)
	{
		System.out.println("hello world");
		main();
	}
	public static void main()
	{
		System.out.println("my main invoked");
	}
}