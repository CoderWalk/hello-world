class MyThread extends Thread
{
	public MyThread(String name)
	{
		super(name);
	}
	public void run()
	{
		Thread t=Thread.currentThread();
		String name=t.getName();
		if(t.isDaemon())
		System.out.println(name+" thread is daemon");
		else
		System.out.println(name+" thread is not daemon");
	}
}
class DaemonDemo
{
	public static void main(String[] arr)
	{	
		MyThread t1=new MyThread("A");
		MyThread t2=new MyThread("B");
		MyThread t3=new MyThread("C");
		t2.setDaemon(true);
		t1.start();
		t2.start();
		t3.start();
		
	}
}

