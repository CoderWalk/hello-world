class MyThread extends Thread
{
	public MyThread(String name)
	{
		super(name);
	}
	public void run()
	{
		String name=Thread.currentThread().getName();
		System.out.println(name+" thread starts");
		System.out.println(name+" thread suspend");
		try{
			Thread.sleep(1000);
			System.out.println(name+" thread resumed");
			System.out.println(name+" thread exited");
		}catch(InterruptedException e)
		{
			System.out.println(name+" thread interrupted...");
		}
	}	
}
class InterruptDemo
{
	public static void main(String[] arr)
	{
		System.out.println("starting a lazy thread, give it 5sec to complete");
		MyThread t1=new MyThread("lucifer");
		t1.start();
		try{
			Thread.sleep(5000);
		}catch(Exception e)
		{
			System.out.println(e);
		}
		if(t1.isAlive())
		{
			System.out.println("lazy thread taking too long time, interrupt it...");
			t1.interrupt();
		}
	}
}	