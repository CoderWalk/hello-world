class Buffer
{
	int a;
	public synchronized void produce(int x)
	{
		a=x;
		System.out.println(a+" is produced");
	}
	public synchronized void consume()
	{
		System.out.println(a+" is comsumed");
	}
}
class Producer extends Thread
{
	Buffer b;
	public Producer(Buffer b)
	{
		this.b=b;
	}
	public void run()
	{
		for(int i=1;i<=10;i++)
		b.produce(i);
	}
}
class Consumer extends Thread
{
	Buffer b;
	public Consumer(Buffer b)
	{
		this.b=b;
	}
	public void run()
	{
		for(int i=1;i<=10;i++)
		b.consume();
	}
}
class InterDemo1
{
	public static void main(String[] arr)
	{
		System.out.println("creating Buffer,Producer & Consumer thread");		
		Buffer b=new Buffer();
		Producer p=new Producer(b);
		Consumer c=new Consumer(b);
		p.start();
		c.start();
	}
}