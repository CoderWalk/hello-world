class Printer
{
	public void print(char ch)
	{
		//half line printed
		for(int i=1;i<=30;i++)
		System.out.print(ch);
		try{
				Thread.sleep(2000);
			}catch(Exception e)
			{
				System.out.println(e);
			}
		//remaining half line printed
		for(int i=1;i<=30;i++)
		System.out.print(ch);

		//new line print
		System.out.println();
	}
}
class StarPrinter extends Thread
{
	Printer p;
	public StarPrinter(Printer p)
	{
		this.p=p;
	}
	public void run()
	{
		System.out.println("star-printer starts");
		p.print('*');
		System.out.println("star-printer finished");
	}
}
class HashPrinter extends Thread
{
	Printer p;
	public HashPrinter(Printer p)
	{
		this.p=p;
	}
	public void run()
	{
		System.out.println("hash-printer starts");
		p.print('#');
		System.out.println("hash-printer finished");
	}
}
class AsyncDemo
{
	public static void main(String[] arr)
	{
		System.out.println("creating Printer,star&hash printer");
		Printer p=new Printer();
		StarPrinter st=new StarPrinter(p);
		HashPrinter hs=new HashPrinter(p);
		st.start();
		hs.start();
	}
}