class ThreadDemo
{
	public static void main(String[] arr)
	{
		System.out.println("obtain the ref of current-thread");
		Thread t=Thread.currentThread();
		System.out.println("It is "+t.getName()+" thread");
		System.out.println("its priority is: "+t.getPriority());
		System.out.println("change its name & priority");
		t.setName("neo");
		t.setPriority(7);
		System.out.println("sleep it for 5sec");
		try{
			Thread.sleep(5000);
		}catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println(t.getName()+" thread resumed with priority "+t.getPriority());
	}
}