class Buffer
{
	int a;
	boolean produced=false;
	public synchronized void produce(int x)
	{
		if(produced)
		{
			System.out.println("producer enter monitor,turn out of suspending");
			try{
				wait();
			}catch(Exception e)
			{
				System.out.println(e);
			}
		}
		a=x;
		System.out.println(a+" is produced");
		produced=true;
		notify();
	}
	public synchronized void consume()
	{
		if(!produced)
		{
			System.out.println("consumer enter monitor,turn out of suspending");
			try{
				wait();
			}catch(Exception e)
			{
				System.out.println(e);
			}
		}
		System.out.println(a+" is comsumed");
		produced=false;
		notify();
	}
}
class Producer extends Thread
{
	Buffer b;
	public Producer(Buffer b)
	{
		this.b=b;
	}
	public void run()
	{
		for(int i=1;i<=10;i++)
		b.produce(i);
	}
}
class Consumer extends Thread
{
	Buffer b;
	public Consumer(Buffer b)
	{
		this.b=b;
	}
	public void run()
	{
		for(int i=1;i<=10;i++)
		b.consume();
	}
}
class InterDemo2
{
	public static void main(String[] arr)
	{
		System.out.println("creating Buffer,Producer & Consumer thread");		
		Buffer b=new Buffer();
		Producer p=new Producer(b);
		Consumer c=new Consumer(b);
		p.start();
		c.start();
	}
}