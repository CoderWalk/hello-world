package Q5;
import Q4.A;
class B extends A
{
	public void show()
	{
		super.show();
	}	
}
public class C
{
	public static void main(String[] arr)
	{
		B ref=new B();
		ref.show();
	}
}