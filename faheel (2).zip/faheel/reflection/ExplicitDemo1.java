class A
{
	static{
		System.out.println("A is loaded");
	}
	public A()
	{
		System.out.println("A is instantiated");
	}
}
class B
{
	static{
		System.out.println("B is loaded");
	}
	public B()
	{
		System.out.println("B is instantiated");
	}
}
class C
{
	static{
		System.out.println("C is loaded");
	}
	public C()
	{
		System.out.println("C is instantiated");
	}
}
class ExplicitDemo1
{
	public static void main(String[] arr)
	{
		try{
			Class c=Class.forName(arr[0]);
			Object o=c.newInstance();
			System.out.println("indirectly creating an object of a class: "+c.getName());
		}catch(Exception e)
		{	
			System.out.println(e);
		}
	}
}