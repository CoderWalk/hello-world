import java.lang.reflect.*;
class MyJavap
{
	public static void main(String[] arr)
	{
		try{
			Class c=Class.forName(arr[0]);
			Field[] f=c.getDeclaredFields();
			Constructor[] con=c.getDeclaredConstructors();
			Method[] m=c.getDeclaredMethods();
			for(int i=0;i<f.length;i++)
			System.out.println(f[i]);

			for(int i=0;i<con.length;i++)
			System.out.println(con[i]);

			for(int i=0;i<m.length;i++)
			System.out.println(m[i]);
		}catch(Exception e)
		{	
			System.out.println(e);
		}
	}
}