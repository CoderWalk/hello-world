import java.lang.reflect.*;
class A
{
	private void show(int x)
	{
		System.out.println("show invoked: "+x);
	}
}
class InvokeDemo2
{
	public static void main(String[] arr)
	{
		try{
			Class c=Class.forName("A");
			Object o=c.newInstance();
			Method m=c.getDeclaredMethod("show",new Class[]{int.class});
			m.setAccessible(true);
			m.invoke(o,100);
		}catch(Exception ex)
		{	
			System.out.println(ex);	
		}
	}
}