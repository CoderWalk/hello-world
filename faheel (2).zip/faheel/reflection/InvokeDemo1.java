import java.lang.reflect.*;
class A
{
	private void show()
	{
		System.out.println("show invoked");
	}
}
class InvokeDemo1
{
	public static void main(String[] arr)
	{
		try{
			Class c=Class.forName("A");
			Object o=c.newInstance();
			Method m=c.getDeclaredMethod("show",null);
			m.setAccessible(true);
			m.invoke(o,null);
		}catch(Exception ex)
		{	
			System.out.println(ex);	
		}
	}
}