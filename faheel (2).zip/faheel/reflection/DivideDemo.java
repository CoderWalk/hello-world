class DivideDemo
{
	public static void main(String[] arr)
	{
		try{
			int a=Integer.parseInt(arr[0]);
			int b=Integer.parseInt(arr[1]);
			int c=a/b;
			System.out.println("result="+c);
		}catch(ArithmeticException e)
		{
			System.out.println("second no should not be zero");
		}
		catch(NumberFormatException e)
		{
			System.out.println("provide only no");
		}
		catch(ArrayIndexOfBoundsException e)
		{
			System.out.println("provide two no");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}