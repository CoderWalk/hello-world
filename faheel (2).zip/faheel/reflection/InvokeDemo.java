class A
{
	private void show()
	{
		System.out.println("show invoked");
	}
}
class InvokeDemo
{
	public static void main(String[] arr)
	{
		A x=new A();
		x.show();
	}
}