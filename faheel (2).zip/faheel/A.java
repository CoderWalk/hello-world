class A
{
	private void show()
	{
		System.out.println("from A");
	}
	public static void invoke(A ref)
	{
		ref.show();//identify binding of this method call
	}
}