class OverloadDemo3
{
	static{
		main(new String[]{"faheel"});	
	}
	public static void main(String... arr)//var args
	{
		System.out.println("hello: "+arr[0]);
	}
}