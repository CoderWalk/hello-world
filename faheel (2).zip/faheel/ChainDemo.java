class A extends Object
{
	public A()
	{
		super();
		System.out.println("from A");
	}
}
class B extends A
{
	public B()
	{
		super();
	}
}
class C extends B
{
	public C()
	{
		super();
		System.out.println("from C");
	}
}
class ChainDemo
{
	public static void main(String[] arr)
	{
		A x=new A();
		B y=new B();
		C z=new C();
	}
}