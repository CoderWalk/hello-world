import java.util.*;
class SetDemo
{
	public static void main(String[] arr)
	{
		HashSet hs=new HashSet();
		hs.add("rahul");
		hs.add("ameen");
		hs.add("faheel");
		hs.add("zaid");
		hs.add("rahul");
		System.out.println("there are" +hs.size()+" elements in set");
		Iterator itr=hs.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		TreeSet ts=new TreeSet();
		ts.addAll(hs);
		System.out.println("elements of tree set");
		itr=ts.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
	}	
}




