import java.util.*;
class MapDemo
{
	public static void main(String[] arr)
	{
		HashMap hs=new HashMap();
		hs.put("faheel","developer");
		hs.put("ameen","developer");
		hs.put("zaid","DBA");
		hs.put("zaid","Teacher");
		System.out.println("there are "+hs.size()+" elements");
		Set s=hs.entrySet();
		Iterator itr=s.iterator();
		while(itr.hasNext())
		{
			Map.Entry m=(Map.Entry)itr.next();
			System.out.println(m.getKey()+" "+m.getValue());
		}
	}	
}




