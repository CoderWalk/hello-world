import java.util.*;
class ListDemo1
{
	public static void main(String[] arr)
	{
		ArrayList list=new ArrayList();
		list.add("rahul");
		list.add("ameen");
		list.add(1,"faheel");
		list.add("zaid");
		list.add("rahul");
		System.out.println("there are" +list.size()+" elements in list");
		Iterator itr=list.iterator();
		System.out.println("elements in normal order");
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		ListIterator ltr=list.listIterator(list.size());
		System.out.println("elements in reverse order");
		while(ltr.hasPrevious())
		{
			System.out.println(ltr.previous());
		}
		//System.out.println(list);
	}	
}




