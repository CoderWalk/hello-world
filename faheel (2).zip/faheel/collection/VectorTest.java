import java.util.*;
class VectorTest
{
	static Enumeration e;
	public static void main(String[] arr)
	{
		Vector v=new Vector();
		v.addElement("A");
		v.addElement("B");
		v.addElement("C");
		v.addElement("D");
		e=v.elements();
		System.out.println("creating a thread to traverse elements");
		Thread t=new Thread()//anonymous inner class starts
		{
			public void run()
			{	
				while(e.hasMoreElements())
				{
					System.out.println(e.nextElement());
					try{
						Thread.sleep(2000);
					}catch(Exception ex)
					{	
						System.out.println(ex);	
					}
				}
			}
		};//anonymous inner class finished
		System.out.println("starting a thread");
		t.start();
		try{
			Thread.sleep(2000);
		}catch(Exception ex)
		{
			System.out.println(ex);
		}
		System.out.println("removing C from the vector & add E in it");
		v.removeElement("C");
		v.addElement("E");
	}
}