import java.util.*;
class VectorDemo
{
	public static void main(String[] arr)
	{
		Vector v=new Vector();
		v.addElement("amit");
		v.add("faheel");
		v.add(1,"ameen");
		v.addElement("rahul");
		v.addElement("amit");
		System.out.println("there are "+v.size()+" elemenst in vector");
		/*Enumeration e=v.elements();
		while(e.hasMoreElements())
		{
			System.out.println(e.nextElement());
		}*/
		Iterator itr=v.iterator();
		while(itr.hasNext())
		System.out.println(itr.next());
	}
}

