import java.util.*;
class ListDemo
{
	public static void main(String[] arr)
	{
		ArrayList list=new ArrayList();
		list.add("rahul");
		list.add("ameen");
		list.add(1,"faheel");
		list.add("zaid");
		list.add("rahul");
		System.out.println("there are" +list.size()+" elements in list");
		Iterator itr=list.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		System.out.println("search zaid in the list is: "+list.contains("zaid"));
		System.out.println("removing zaid from the list");
		list.remove("zaid");
		System.out.println("now search of zaid in the list is: "+list.contains("zaid"));
	}	
}




