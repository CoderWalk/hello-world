import java.util.*;
class MapDemo1
{
	public static void main(String[] arr)
	{
		HashMap hs=new HashMap();
		hs.put("faheel","developer");
		hs.put("ameen","tester");
		hs.put("zaid","DBA");
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("enter name to find out the job,end to finish");
			String key=sc.next();			
			if(key.equals("end"))
				break;
			String value=(String)hs.get(key);
			System.out.println("job is: "+value);
		}
	}	
}




