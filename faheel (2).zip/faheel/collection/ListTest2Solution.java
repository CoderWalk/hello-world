import java.util.*;
class Student
{
	int fees;
	String name,course;
	public Student(String x,String y,int z)
	{
		name=x;
		course=y;
		fees=z;
	}
	public void show()
	{
		System.out.println(name+" "+course+" "+fees);
	}
	public boolean equals(Object o)
	{
		System.out.println("************");
		Student s=(Student)o;
		return name.equals(s.name)&&course.equals(s.course)&&fees==s.fees;
	}
}
class ListTest2Solution
{
	public static void main(String[] arr)
	{
		ArrayList list=new ArrayList();
		list.add(new Student("ameen","django",8000));
		list.add(new Student("faheel","spring",9000));
		list.add(new Student("zaid","rest-api",7000));
		Iterator itr=list.iterator();
		while(itr.hasNext())
		{
			Student s=(Student)itr.next();
			s.show();
		}
		Student temp=new Student("zaid","rest-api",7000);
		System.out.println("details of temp");
		temp.show();
		System.out.println("searching of temp in the list: "+list.contains(temp));
	}
}