import java.util.*;
class ListTest1
{
	static Iterator itr;
	public static void main(String[] arr)
	{
		ArrayList list=new ArrayList();
		list.add("A");
		list.add("B");
		list.add("C");
		list.add("D");
		itr=list.iterator();
		System.out.println("creating a thread to traverse elements");
		Thread t=new Thread()//anonymous inner class starts
		{
			public void run()
			{	
				while(itr.hasNext())
				{
					System.out.println(itr.next());
					try{
						Thread.sleep(2000);
					}catch(Exception ex)
					{	
						System.out.println(ex);	
					}
				}
			}
		};//anonymous inner class finished
		System.out.println("starting a thread");
		t.start();
		try{
			Thread.sleep(2000);
		}catch(Exception ex)
		{
			System.out.println(ex);
		}
		System.out.println("removing C from the List & add E in it");
		list.remove("C");
		list.add("E");
	}
}