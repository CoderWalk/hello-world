import java.util.*;
class Student
{
	int fees;
	String name,course;
	public Student(String x,String y,int z)
	{
		name=x;
		course=y;
		fees=z;
	}
	public void show()
	{
		System.out.println(name+" "+course+" "+fees);
	}
	public boolean equals(Object o)
	{
		System.out.println("************");
		Student s=(Student)o;
		return name.equals(s.name)&&course.equals(s.course)&&fees==s.fees;
	}	
}
class NameComparator implements Comparator
{
	public int compare(Object o,Object q)
	{
		Student s=(Student)o;
		Student t=(Student)q;
		return s.name.compareTo(t.name);
	}
}
class CourseComparator implements Comparator
{
	public int compare(Object o,Object q)
	{
		Student s=(Student)o;
		Student t=(Student)q;
		return s.course.compareTo(t.course);
	}
}
class FeesComparator implements Comparator
{
	public int compare(Object o,Object q)
	{
		Student s=(Student)o;
		Student t=(Student)q;
		return s.fees-t.fees;
	}
}
class SetTestProblm2Solution2
{
	public static void main(String[] arr)
	{
		TreeSet hs=new TreeSet(new FeesComparator());
		hs.add(new Student("ameen","django",8000));
		hs.add(new Student("faheel","spring",9000));
		hs.add(new Student("zaid","rest-api",7000));
		Iterator itr=hs.iterator();
		while(itr.hasNext())
		{
			Student s=(Student)itr.next();
			s.show();
		}
		Student temp=new Student("zaid","rest-api",7000);
		System.out.println("details of temp");
		temp.show();
		System.out.println("searching of temp in the set: "+hs.contains(temp));
	}
}