import java.util.*;
class Student
{
	int fees;
	String name,course;
	public Student(String x,String y,int z)
	{
		name=x;
		course=y;
		fees=z;
	}
	public void show()
	{
		System.out.println(name+" "+course+" "+fees);
	}
	public boolean equals(Object o)
	{
		System.out.println("************");
		Student s=(Student)o;
		return name.equals(s.name)&&course.equals(s.course)&&fees==s.fees;
	}
}
class SetTestProblm
{
	public static void main(String[] arr)
	{
		HashSet hs=new HashSet();
		hs.add(new Student("ameen","django",8000));
		hs.add(new Student("faheel","spring",9000));
		hs.add(new Student("zaid","rest-api",7000));
		Iterator itr=hs.iterator();
		while(itr.hasNext())
		{
			Student s=(Student)itr.next();
			System.out.println(s.hashCode());
			s.show();
		}
		Student temp=new Student("zaid","rest-api",7000);
		System.out.println("details of temp");
		System.out.println(temp.hashCode());
		temp.show();
		System.out.println("searching of temp in the set: "+hs.contains(temp));
	}
}