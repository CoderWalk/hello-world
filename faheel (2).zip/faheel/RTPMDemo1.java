abstract class Account
{
	String name;
	double bal;
	public Account(String n,double d)
	{
		name=n;
		bal=d;
	}
	public final void deposit(double a)
	{
		bal=bal+a;
	}
	public final void display()
	{
		System.out.println("name="+this.name);
		System.out.println("bal="+this.bal);
		System.out.println("rate="+this.getRate());
		System.out.println("type="+this.getClass().getName());
		System.out.println("----------------------------------");
	}	
	public abstract double getRate();
	public static void creditIntrest(Account a)
	{
		double ir=a.getRate();
		ir=((a.bal)*(ir/4))/100;
		a.deposit(ir);
	}
}
class Saving extends Account
{
	public Saving(String n,double d)
	{
		super(n,d);
	}
	public double getRate()
	{
		return 5;
	}
}
class Fixed extends Account
{
	public Fixed(String n,double d)
	{
		super(n,d);
	}
	public double getRate()
	{
		return 7;
	}
}
class Current extends Account
{
	public Current(String n,double d)
	{
		super(n,d);
	}
	public double getRate()
	{
		return 2;
	}
}
class RTPMDemo1
{
	public static void main(String[] arr)
	{
		System.out.println("creating some account obj...");
		Saving x=new Saving("abc",10000);
		Fixed y=new Fixed("xyz",12000);
		Current z=new Current("pqr",14000);
		System.out.println("details of accounts...");
		x.display();
		y.display();
		z.display();
		System.out.println("crediting intrest in accounts");
		Account.creditIntrest(x);
		Account.creditIntrest(y);
		Account.creditIntrest(z);
		System.out.println("details of accounts after crediting intrest...");
		x.display();
		y.display();
		z.display();	
	}
}