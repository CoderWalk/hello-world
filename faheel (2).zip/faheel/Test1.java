class Test1
{
	public Test1()
	{
		System.out.println("default const invoked");
	}
	public Test1(int x)
	{
		System.out.println("argumented const invoked");
	}
	public static void main(String[] arr)
	{
		Test1 t=new Test1();
	}
}