class First
{
	public static void main(String[] faheel)
	{
		System.out.println("hello world");
	}
}