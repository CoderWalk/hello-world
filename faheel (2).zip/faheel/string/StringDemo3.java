class StringDemo3
{
	public static void main(String[] arr)
	{
		String s1=new String("aligarh");
		s1=s1.concat("city");	
		System.out.println(s1);
	}
}