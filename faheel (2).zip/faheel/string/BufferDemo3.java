class BufferDemo3
{
	public static void main(String[] arr)
	{
		StringBuffer s2=new StringBuffer("aligarh");
		StringBuffer s3=new StringBuffer(10);
		s2.append("city");
		System.out.println(s2);
		System.out.println(s2.reverse().reverse().insert(11,'Q'));
		String s=s2.toString();
		System.out.println(s);
		s3.append("nnnnnnnnnutuuuuuuuuutte");
		System.out.println(s3.length()+" "+s3.capacity());
		
	}
}