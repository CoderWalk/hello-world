class StringDemo5
{
	public static void main(String[] arr)
	{
		String s1=new String("winter");
		s1.concat("fall");
		String s2=s1.concat("spring");
		s2.concat("summer");
		System.out.println(s1);
		System.out.println(s2);
	}
}