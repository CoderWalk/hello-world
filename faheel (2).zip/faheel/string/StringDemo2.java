class StringDemo2
{
	public static void main(String[] arr)
	{
		int a=10;
		byte b=3;
		short c=45;
		long d=12l;
		char e='E';
		float f=3.4f;
		double g=3.5;
		//show(String.valueOf(a));		
		Integer i=new Integer(a);
		show(i.toString());
		show(String.valueOf(b));
		show(String.valueOf(c));
		show(String.valueOf(d));
		show(String.valueOf(e));
		show(String.valueOf(f));	
		show(String.valueOf(g));
	}	
	public static void show(String s)
	{
		System.out.println(s);
	}
}