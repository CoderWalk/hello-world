class StringDemo1
{
	public static void main(String[] arr)
	{	
		String s1=new String("Aligarh");
		System.out.println(s1.toLowerCase());
		System.out.println(s1.toUpperCase());		
		System.out.println(s1.length());
		System.out.println(s1.concat("city"));
		byte[] b=s1.getBytes();
		for(byte e: b)
		System.out.println((char)e);
		char[] c=s1.toCharArray();
		for(int i=0;i<c.length;i++)
		System.out.println(c[i]);
		String s2="    faheel";
		System.out.println(s2);
		System.out.println(s2.trim());
		System.out.println(s1.charAt(2));
		String s3="hello how are you";
		System.out.println(s3.substring(2));
		System.out.println(s3.substring(2,12));
		String[] data=s3.split(" ");
		for(String r: data)
		System.out.println(r);
		System.out.println(s3.indexOf('h'));
		System.out.println(s3.indexOf("how"));
		System.out.println(s3.lastIndexOf('h'));
		System.out.println(s1.equals("aligarh"));
		System.out.println(s1.equalsIgnoreCase("aligarh"));
	}
}
