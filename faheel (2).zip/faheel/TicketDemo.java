class Ticket
{
	//instance or non-static member
	int no;
	//class member(static)
	static int counter;
	static{
		counter=0;
	}
	public Ticket()
	{
		no=++counter;
	}
	public void showNo()
	{	
		System.out.println("It is ticket no"+no);
	}
	public static int getCounter()
	{
		return counter;
	}
}
class TicketDemo
{
	public static void main(String[] arr)
	{
		System.out.println("creating some ticket obj...");
		Ticket t1=new Ticket();
		Ticket t2=new Ticket();
		Ticket t3=new Ticket();
		t1.showNo();
		t2.showNo();
		t3.showNo();
		System.out.println("Total ticket="+Ticket.getCounter());
		System.out.println("Total ticket...="+Ticket.counter);
	}
}