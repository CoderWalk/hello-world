class Room
{
	int door,area;
	public Room(int x,int y)
	{
		door=x;
		area=y;
	}
	public void show()
	{
		System.out.println("door="+door);
		System.out.println("area="+area);
	}
}
class House
{
	int area;
	Room br,dr;
	public House()
	{
		area=1000;
		br=new Room(2,400);
		dr=new Room(4,600);
	}
	public void display()
	{
		System.out.println("area of the house is: "+area+" sq-feet");
		System.out.println("it has one bedroom with following description");
		br.show();
		System.out.println("it has one drawingroom with following description");
		dr.show();
	}
}
class CompositionDemo
{
	public static void main(String[] arr)
	{
		House h=new House();
		h.display();
	}
}