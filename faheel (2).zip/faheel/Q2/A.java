package Q2;
public class A
{
	public void add(int x,int y)
	{
		System.out.println("sum="+(x+y));
	}
}