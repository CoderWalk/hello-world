import java.util.*;
class Rectangle
{
	//attributes
	private int l,b;
	//behavior
	public void showDimension()
	{
		System.out.println("length="+l);
		System.out.println("breadth="+b);
	}
	public int area()
	{
		int result=l*b;
		return result;
	}
	public void setDimension(int x,int y)
	{
		l=x;
		b=y;
	}
		
}
class RectTest1
{
	public static void main(String[] arr)
	{
		Rectangle r=new Rectangle();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter length");
		int a=sc.nextInt();
		System.out.println("enter breadth");
		int b=sc.nextInt();
		r.setDimension(a,b);
		r.showDimension();
		System.out.println("area of rect="+r.area());
	}
}