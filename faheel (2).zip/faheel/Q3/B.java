package Q3;
import Q2.A;
public class B
{
	public static void main(String[] arr)
	{
		A x=new A();
		x.add(10,20);
	}
}