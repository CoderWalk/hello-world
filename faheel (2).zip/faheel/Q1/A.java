package Q1;
public class A
{
	public static void main(String[] arr)
	{
		System.out.println("pack invoked");
	}
}