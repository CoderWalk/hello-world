interface A
{
	default void show1(){System.out.println("hello");}
	public void show();
	default void display()
	{
		System.out.println("display invoked");
	}
	default void display1()
	{  
		System.out.println("display1 invoked");
	}
}
class B implements A
{
	public void show()
	{
		System.out.println("show invoked");
	}
	public void display()
	{
		System.out.println("hi kuldeep");
	}	
}
class DefaultDemo
{
	public static void main(String[] arr)
	{
		B x=new B();
		x.show();
		x.display();
		x.display1();
	}
}