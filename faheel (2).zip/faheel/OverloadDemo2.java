class OverloadDemo2
{
	static{
		System.out.println("hello faheel");
		System.exit(432);
	}
}