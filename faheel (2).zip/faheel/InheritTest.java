class Common
{
	int l,b;
	public Common(int x,int y)
	{
		l=x;
		b=y;
	}
	public void show()
	{
		System.out.println("length="+l);
		System.out.println("breadth="+b);
	}
}
class Rectangle extends Common
{
	public Rectangle(int x,int y)
	{
		super(x,y);
	}
	public int area()
	{
		return l*b;	
	}
}
class Cuboid extends Common
{
	//int h;
	int l;
	public Cuboid(int x,int y,int z)
	{
		super(x,y);
		//h=z;
		l=z;
	}
	public int volume()
	{
		//return l*b*h;
		return super.l*b*l;
	}
	public void show()
	{
		super.show();
		//System.out.println("height="+h);
		System.out.println("height="+l);
	}
}
class InheritTest
{
	public static void main(String[] a)
	{
		Rectangle r=new Rectangle(4,5);
		r.show();
		System.out.println("area of rect="+r.area());
		Cuboid c=new Cuboid(4,5,6);
		c.show();
		System.out.println("volume of cuboid="+c.volume());
	}
}