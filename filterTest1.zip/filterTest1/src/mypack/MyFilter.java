package mypack;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

//@WebFilter("/MyFilter")
public class MyFilter implements Filter {

  	FilterConfig config;
  	
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
		config=fConfig;
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

		String url=config.getInitParameter("url");
		HttpServletRequest req=(HttpServletRequest)request;
		String uri=req.getRequestURI();
		if(uri.endsWith("html") || uri.endsWith(url))
		{
			System.out.println("request is coming for .html page or welcome page");
			chain.doFilter(request, response);
		}
		else
		{

			System.out.println("request is coming for exit page");
			//obtain existing session not to create new one
			HttpSession session=req.getSession(false);
			if(session!=null)
			{
				System.out.println("session is not null"+session);
				chain.doFilter(request, response);
			}
			else
			{
				System.out.println("session is null");
				RequestDispatcher rd=request.getRequestDispatcher("index.html");
				rd.forward(request, response);
			}
		}
	}
	public void destroy() {
		// TODO Auto-generated method stub
	}
	
}
