import java.io.*;
class ReadDemo2
{
	public static void main(String[] arr)
	{	
		try{
		FileInputStream f=new FileInputStream(arr[0]);
		int size=f.available();
		byte[] b=new byte[size];
		f.read(b);
		String s=new String(b);
		System.out.println(s);
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}
}