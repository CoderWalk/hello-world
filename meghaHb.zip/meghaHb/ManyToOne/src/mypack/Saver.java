package mypack;

import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.*;
public class Saver {

	public static void main(String[] args) {

				
		Trainer t1=new Trainer("rahul");
		Trainer t2=new Trainer("ishaan");
		
		Batch b1=new Batch("weekdays", "3-5", "java",t1);
		Batch b2=new Batch("weekends", "11-2", "C++",t1);
		Batch b3=new Batch("weekdays", "5-7", "C",t1);
		
		Batch b4=new Batch("weekends", "10-12", "django",t2);
		Batch b5=new Batch("weekdays", "5-7", "adv-java",t2);
		
		Session session=MyFactory.getSession();
		Transaction tx=session.beginTransaction();
		session.save(b1);
		session.save(b2);
		session.save(b3);
		session.save(b4);
		session.save(b5);
		tx.commit();
		session.close();
		System.out.println("successfully saved");
	}

}
