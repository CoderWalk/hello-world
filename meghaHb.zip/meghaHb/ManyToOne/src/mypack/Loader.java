package mypack;

import java.util.*;

import org.hibernate.Session;

public class Loader {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter trainer id");
		Scanner sc=new Scanner(System.in);
		int id=sc.nextInt();
		Session session=MyFactory.getSession();
		Trainer  t=(Trainer)session.get(Trainer.class,id);
		System.out.println("trainer name is: "+t.getName());
		Set<Batch> s=t.getBatches();
		for(Batch b: s)
		{
			System.out.println(b.getMode()+" "+b.getSlot()+" "+b.getCourse());
		}
		System.out.println("-------------------");
		System.out.println("enter batch id");
		int bid=sc.nextInt();
		Batch b=(Batch)session.get(Batch.class,bid);
		System.out.println(b.getMode()+" "+b.getSlot()+" "+b.getCourse());
		Trainer t1=b.getTrainer();
		System.out.println(t1.getName());
		System.out.println("successfully loaded....");
	}

}
