package mypack;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class MyFactory {

	private static SessionFactory sf;
	static {
		AnnotationConfiguration cf=new AnnotationConfiguration().configure();
		sf=cf.buildSessionFactory();
	}
	public static Session getSession()
	{
		return sf.openSession();
	}
	public static SessionFactory getSessionFactory()
	{
		return sf;
	}
}
