package mypack;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="students")
@PrimaryKeyJoinColumn(name="personId")
public class Student extends Person {

	private String course;
	private int fees;
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(String name,String course, int fees) {
		super(name);
		this.course = course;
		this.fees = fees;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public int getFees() {
		return fees;
	}
	public void setFees(int fees) {
		this.fees = fees;
	}
	
}
