package mypack;

import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.*;
public class Saver {

	public static void main(String[] args) {

		Set<Batch> s1=new HashSet<Batch>();
		s1.add(new Batch("weekdays", "3-5", "python"));
		s1.add(new Batch("weekends", "11-1", "C"));
		s1.add(new Batch("weekdays", "10-12", "C++"));
		
		Set<Batch> s2=new HashSet<Batch>();
		s2.add(new Batch("weekdays", "12-2", "django"));
		s2.add(new Batch("weekends", "4-6", "hibernate"));
		
		Trainer t1=new Trainer("megha", s1);
		Trainer t2=new Trainer("rahul", s2);
		
		Session session=MyFactory.getSession();
		Transaction tx=session.beginTransaction();
		session.save(t1);
		session.save(t2);
		tx.commit();
		session.close();
		System.out.println("successfully saved");
	}

}
