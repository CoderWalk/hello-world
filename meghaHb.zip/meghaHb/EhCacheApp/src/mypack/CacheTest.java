package mypack;

import java.util.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.stat.SecondLevelCacheStatistics;

public class CacheTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory factory=MyFactory.getSessionFactory();
		for(int i=1;i<=2;i++)
		{
		System.out.println("loading emp with id-1");
		Session session=MyFactory.getSession();
		long t1=System.currentTimeMillis();
		Emp e=(Emp)session.get(Emp.class,1);
		Set<Previlige> prev=e.getPreviliges();
		long t2=System.currentTimeMillis();
		System.out.println("total time taken to load objects"
				+ " is "+(t2-t1)+" miliseconds...");
		System.out.println("emp details");
		System.out.println(e.getName()+" "+e.getJob()+" "+e.getSalary());
		System.out.println("previligies availed by emp");
		for(Previlige p: prev)
			System.out.println(p.getName()+" "+p.getCost());
		
		SecondLevelCacheStatistics stat1=factory.getStatistics().
				getSecondLevelCacheStatistics("r1");
		SecondLevelCacheStatistics stat2=factory.getStatistics().
				getSecondLevelCacheStatistics("r2");
		
		System.out.println("statistics of region r1");
		System.out.println(stat1);
		System.out.println("---------------------------------------");
		System.out.println("statistics of region r2");
		System.out.println(stat2);
		
		}
	}

}
