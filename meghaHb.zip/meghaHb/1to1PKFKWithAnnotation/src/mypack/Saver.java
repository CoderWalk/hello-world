package mypack;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class Saver {

	public static void main(String[] args) {

		System.out.println("saving country objects...");
		Session session=MyFactory.getSession();
		Country c1=new Country("India", new HeadOfState("R.N.Kovind", "President"));
		Country c2=new Country("UK", new HeadOfState("Elizabeth2", "Queen"));
		//obtain transaction
		Transaction tx=session.beginTransaction();
		session.save(c1);
		session.save(c2);
		//transaction commmit
		tx.commit();
		//session close
		session.close();
		System.out.println("successfully saved");
	}

}
