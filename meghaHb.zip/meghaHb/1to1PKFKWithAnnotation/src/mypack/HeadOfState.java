package mypack;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

//owned entity
@Entity
@Table(name="hos")
public class HeadOfState {

	//state
	@Id
	@GeneratedValue
	private int id;
	private String name,title;
	//relation
	@OneToOne(mappedBy="hos")
	@Transient
	private Country country;
	
	public HeadOfState() {
		super();
		// TODO Auto-generated constructor stub
	}
	public HeadOfState(String name, String title) {
		super();
		this.name = name;
		this.title = title;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Country getCountry() {
		return country;
	}
	public void setCountry(Country country) {
		this.country = country;
	}
	
}
