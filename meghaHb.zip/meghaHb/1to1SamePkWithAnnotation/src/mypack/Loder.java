package mypack;

import java.util.Scanner;

import org.hibernate.Session;

public class Loder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session=MyFactory.getSession();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter country id");
		int cid=sc.nextInt();
		Country c=(Country)session.get(Country.class, cid);
		System.out.println("country name: "+c.getName());
		HeadOfState hos=c.getHos();
		System.out.println("head of state details");
		System.out.println(hos.getName()+" "+hos.getTitle());
		System.out.println("enter hos id");
		int hid=sc.nextInt();
		System.out.println("---------------------------------");
		HeadOfState ho=(HeadOfState)session.get(HeadOfState.class, hid);
		System.out.println(ho.getTitle()+" "+ho.getName());
		Country co=ho.getCountry();
		System.out.println(co.getName());
	}

}
