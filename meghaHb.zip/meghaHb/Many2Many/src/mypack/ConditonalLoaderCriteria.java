package mypack;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import java.util.*;
public class ConditonalLoaderCriteria {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session=MyFactory.getSession();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter previlige count");
		int count=sc.nextInt();
		System.out.println("loading those emp who avail "
		+count+" or more prevligies");
		Criteria c=session.createCriteria(Emp.class);
		c.add(Restrictions.sizeGe("previliges",count));
		List<Emp> list=c.list();
		System.out.println("details of emp");
		for(Emp e : list)
			System.out.println(e.getName()+" "+e.getJob()+" "+e.getSalary());
		session.close();
		sc.close();
		System.out.println("successfully fetched...");
	}

}
