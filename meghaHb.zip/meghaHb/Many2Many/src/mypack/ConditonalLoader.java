package mypack;
import org.hibernate.Query;
import org.hibernate.Session;
import java.util.*;
public class ConditonalLoader {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session=MyFactory.getSession();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter previlige count");
		int count=sc.nextInt();
		System.out.println("loading those emp who avail "
		+count+" or more prevligies");
		Query q=session.createQuery("from Emp e where size(e.previliges)>=?");
		q.setInteger(0, count);
		List<Emp> list=q.list();
		System.out.println("details of emp");
		for(Emp e : list)
			System.out.println(e.getName()+" "+e.getJob()+" "+e.getSalary());
		session.close();
		sc.close();
		System.out.println("successfully fetched...");
	}

}
