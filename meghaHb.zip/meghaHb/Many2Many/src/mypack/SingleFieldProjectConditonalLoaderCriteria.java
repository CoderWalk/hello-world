package mypack;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import java.util.*;
public class SingleFieldProjectConditonalLoaderCriteria {

	public static void main(String[] args) {

		Session session=MyFactory.getSession();
		Scanner in=new Scanner(System.in);
		System.out.print("Enter Emp count: ");
		int count=in.nextInt();
		System.out.println(
			"Loading those previlige names in asc order, which are avail "
				+count+" or more employees ...");
		Criteria c=session.createCriteria(Previlige.class);
		c.setProjection(Projections.property("name"));
		c.addOrder(Order.asc("name"));
		c.add(Restrictions.sizeGe("employees",count));
		List<String> list=c.list();
		System.out.println("following prevliges are loaded:");
		for(String name: list)
		{
			System.out.println(name);
		}
		session.close();
		in.close();
	}

}
