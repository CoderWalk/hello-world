package mypack;
import org.hibernate.Query;
import org.hibernate.Session;
import java.util.*;
public class MultiFieldProjectConditonalLoader {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session=MyFactory.getSession();
		System.out.println("loading emp name,salary desc order by salary");
		Query q=session.createQuery("select e.name,e.salary from Emp e order by e.salary asc");
		List<Object[]> list=q.list();
		System.out.println("details of emp");
		for(Object[] p : list)
			System.out.println(p[0]+" "+p[1]);
		
		session.close();
		System.out.println("successfully fetched...");
	}

}
