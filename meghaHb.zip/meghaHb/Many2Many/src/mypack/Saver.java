package mypack;

import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.*;
public class Saver {

	public static void main(String[] args) {
		
		Previlige p1=new Previlige("car", 240000);
		Previlige p2=new Previlige("flat", 350000);
		Previlige p3=new Previlige("club-membership", 400000);
		
		Set<Previlige> s1=new HashSet<Previlige>();
		s1.add(p1);s1.add(p2);s1.add(p3);
		
		Set<Previlige> s2=new HashSet<Previlige>();
		s2.add(p1);s2.add(p2); 
		
		Set<Previlige> s3=new HashSet<Previlige>();
		s3.add(p1);
		
		Emp e1=new Emp("ishaan", "CEO", 350000, s1);
		Emp e2=new Emp("megha", "CFO", 250000, s2);
		Emp e3=new Emp("rahul", "Manager", 150000, s3);
		
		System.out.println("saving emp obj..."); 
		Session session=MyFactory.getSession();
		System.out.println("start transaction");
		Transaction tx=session.beginTransaction();
		session.save(e1);
		session.save(e2);
		session.save(e3);
		tx.commit();
		session.close();
		System.out.println("successfully saved");
	}
	

}
