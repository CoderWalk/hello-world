package mypack;
import org.hibernate.Query;
import org.hibernate.Session;
import java.util.*;
public class SingleFieldProjectConditonalLoader {

	public static void main(String[] args) {

		Session session=MyFactory.getSession();
		Scanner in=new Scanner(System.in);
		System.out.print("Enter Emp count: ");
		int count=in.nextInt();
		System.out.println(
			"Loading those previlige names in asc order, which are avail "
				+count+" or more employees ...");
		Query q=session.createQuery(
"select p.name from Previlige p where size(p.employees) >= :ecount order by p.name asc");
		//setting the value of query parameter
		q.setInteger("ecount",count);
		List<String> list=q.list();
		System.out.println("following prevliges are loaded:");
		for(String name: list)
		{
			System.out.println(name);
		}
		session.close();
		in.close();
	}

}
