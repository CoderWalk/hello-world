package mypack;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import java.util.*;
public class AllEmpLoaderCriteria {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session=MyFactory.getSession();
		System.out.println("fetch all emp....");
		Criteria c=session.createCriteria(Emp.class);
		List<Emp> list=c.list();
		for(Emp e: list)
			System.out.println(e.getName()+" "+e.getJob()+" "+e.getSalary());
		
		System.out.println("successfully loaded");
	}

}
