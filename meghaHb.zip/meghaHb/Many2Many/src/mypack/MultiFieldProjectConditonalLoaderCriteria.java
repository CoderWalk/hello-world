package mypack;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;

import java.util.*;
public class MultiFieldProjectConditonalLoaderCriteria {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session=MyFactory.getSession();
		System.out.println("loading emp name,salary desc order by salary");
		Criteria c=session.createCriteria(Emp.class);
		ProjectionList pl=Projections.projectionList();
		pl.add(Projections.property("name"));
		pl.add(Projections.property("salary"));
		c.setProjection(pl);
		c.addOrder(Order.asc("salary"));
		List<Object[]> list=c.list();
		System.out.println("details of emp");
		for(Object[] p : list)
			System.out.println(p[0]+" "+p[1]);
		
		session.close();
		System.out.println("successfully fetched...");
	}

}
