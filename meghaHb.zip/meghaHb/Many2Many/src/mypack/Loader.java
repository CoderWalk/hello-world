package mypack;

import java.util.*;

import org.hibernate.Session;

public class Loader {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter emp id");
		int eid=sc.nextInt();
		Session session=MyFactory.getSession();
		Emp e=(Emp)session.get(Emp.class,eid);
		System.out.println("emp details");
		System.out.println(e.getName()+" "+e.getJob()+" "+e.getSalary());
		Set<Previlige> prev=e.getPreviliges();
		System.out.println("previligies availed by emp");
		for(Previlige p: prev)
			System.out.println(p.getName()+" "+p.getCost());
		System.out.println("--------------------------------------");
		System.out.println("enter previlige id");
		int pid=sc.nextInt();
		Previlige p=(Previlige)session.get(Previlige.class, pid);
		System.out.println("details of previlige");
		System.out.println(p.getName()+" "+p.getCost());
		Set<Emp> emp=p.getEmployees();
		System.out.println("emp details who availed these previliges");
		for(Emp r: emp)
			System.out.println(r.getName()+" "+r.getJob()+" "+r.getSalary());
		System.out.println("successfully loaded....");
	}

}
