package mypack;

import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.*;
public class Saver {

	public static void main(String[] args) {

		Set<Batch> s1=new HashSet<Batch>();
		s1.add(new Batch("weekdays", "11-2", "java"));
		s1.add(new Batch("weekends", "3-5", "C"));
		s1.add(new Batch("weekdays", "5-7", "C++"));

		Set<Batch> s2=new HashSet<Batch>();
		s2.add(new Batch("weekdays", "8-10", "hibernate"));
		s2.add(new Batch("weekends", "12-2", "python"));
		s2.add(new Batch("weekends", "5-7", "spring"));
		
		Trainer t1=new Trainer("rahul", s1);
		Trainer t2=new Trainer("ishaan", s2);
		
		Session session=MyFactory.getSession();
		Transaction tx=session.beginTransaction();
		session.save(t1);
		session.save(t2);
		tx.commit();
		session.close();
		System.out.println("successfully saved");
	}

}
