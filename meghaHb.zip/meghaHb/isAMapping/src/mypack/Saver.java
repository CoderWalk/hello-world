package mypack;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class Saver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("saving person family...");
		Session session=MyFactory.getSession();
		Person p=new Person("megha");
		Employee e=new Employee("ishaan", "developer", 45000);
		Student s=new Student("soni", "dzango", 6000);
		Transaction tx=session.beginTransaction();
		session.save(p);
		session.save(e);
		session.save(s);
		tx.commit();
		session.close();
		System.out.println("successfullly saved...");
	}

}
