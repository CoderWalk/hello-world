package mypack;

import java.util.Scanner;

import org.hibernate.Session;

public class LazyLoading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id to load an entity");
		int id=sc.nextInt();
		Session session=MyFactory.getSession();
		Emp e=(Emp)session.load(Emp.class, id);
		session.close();
		System.out.println("entity loaded");
		System.out.println("state of an entity");
		System.out.println(e.getId()+" "+e.getName()
		+" "+e.getJob()+" "+e.getSalary());
		System.out.println("session closed");
		//session.close();
	}

}
