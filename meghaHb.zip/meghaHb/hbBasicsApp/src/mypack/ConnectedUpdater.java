package mypack;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class ConnectedUpdater {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Session session=MyFactory.getSession();
		System.out.println("enter id to load entity");
		int id=sc.nextInt();
		Emp e=(Emp)session.get(Emp.class, id);
		System.out.println("current state of an entity");
		System.out.println(e.getId()+" "+e.getName()
		+" "+e.getJob()+" "+e.getSalary());
		System.out.println("enter new name");
		String name=sc.next();
		System.out.println("enter new job");
		String job=sc.next();
		System.out.println("enter new salary");
		int sal=sc.nextInt();
		//just start Transaction & set new data in obj
		Transaction tx=session.beginTransaction();
		e.setName(name);
		e.setJob(job);
		e.setSalary(sal);
		tx.commit();
		session.close();
		System.out.println("successfully updated...");
	}

}
