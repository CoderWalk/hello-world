package mypack;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class EmpDao {

	public Emp getById(int id)
	{
		Session session=MyFactory.getSession();
		Emp e=(Emp)session.get(Emp.class, id);
		session.close();
		return e;
	}
	public void update(Emp e)
	{
		Session session=MyFactory.getSession();
		Transaction tx=session.beginTransaction();
		session.merge(e);
		tx.commit();
		System.out.println("successfully updated...");
	}
}
