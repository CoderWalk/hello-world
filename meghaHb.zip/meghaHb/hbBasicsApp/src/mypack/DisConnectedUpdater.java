package mypack;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class DisConnectedUpdater {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id to update entity");
		int id=sc.nextInt();
		EmpDao dao=new EmpDao();
		Emp e=dao.getById(id);
		System.out.println("current state of an entity");
		System.out.println(e.getId()+" "+e.getName()
		+" "+e.getJob()+" "+e.getSalary());
		System.out.println("enter new name");
		String name=sc.next();
		System.out.println("enter new job");
		String job=sc.next();
		System.out.println("enter new salary");
		int sal=sc.nextInt();
		e.setName(name);
		e.setJob(job);
		e.setSalary(sal);
		dao.update(e);
		System.out.println("main finished");
	}

}
