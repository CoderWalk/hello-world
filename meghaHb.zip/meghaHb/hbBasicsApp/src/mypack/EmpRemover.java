package mypack;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class EmpRemover {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id");
		int id=sc.nextInt();
		Session session=MyFactory.getSession();
		Emp e=(Emp)session.get(Emp.class,id);
		Transaction tx=session.beginTransaction();
		session.delete(e);
		tx.commit();
		session.close();
		System.out.println("successfully removed");
	}

}
