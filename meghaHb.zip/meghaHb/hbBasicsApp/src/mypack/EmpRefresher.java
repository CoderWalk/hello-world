package mypack;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class EmpRefresher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("starting a main thread");
		System.out.println("entity loded with id 1");
		Session session=MyFactory.getSession();
		Emp e=(Emp)session.get(Emp.class, 1);
		System.out.println("entity loaded");
		Thread t=new Thread()
		{
			public void run()
			{
				System.out.println("new thread started");
				Session s=MyFactory.getSession();
				Emp e=(Emp)s.get(Emp.class,1);
				Transaction tx=s.beginTransaction();
				e.setName("aaaa");
				e.setJob("bbbb");
				e.setSalary(1111);
				tx.commit();
				s.close();
				System.out.println("successfully updated child thread completed");
			}
		};
		t.start();
		System.out.println("suspend main thread for 2 sec");
		try {
				Thread.sleep(2000);
		}catch(Exception ex)
		{
			System.out.println(ex);
		}
		System.out.println("main thread resumed, refresh the entity");
		session.refresh(e);
		System.out.println("state of an entity");
		System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary()+" "+e.getJob());
		session.close();
		System.out.println("main thread completed");
	}

}
