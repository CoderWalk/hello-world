package mypack;

import java.util.Scanner;

import org.hibernate.Session;

public class EagerLoading {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id to load entity");
		int id=sc.nextInt();
		Session  session=MyFactory.getSession();
		Emp e=(Emp)session.get(Emp.class,id);
		System.out.println("entity loaded");
		session.close();
		System.out.println("state of an entity: "+e);
		System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary()+" "+e.getJob());
		System.out.println("session closed");
	}

}
