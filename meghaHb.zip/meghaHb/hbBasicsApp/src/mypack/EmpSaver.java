package mypack;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class EmpSaver {

	public static void main(String[] args) {
		
		System.out.println("saving two emp objects....");
		Emp e=new Emp("ashish", "tester", 15000);
		Emp f=new Emp("amit", "accountant", 27000);
		Session session=MyFactory.getSession();
		Transaction tx=session.beginTransaction();
		session.save(e);
		session.save(f);
		tx.commit();
		session.close();
		System.out.println("successfully saved");
	}

}
