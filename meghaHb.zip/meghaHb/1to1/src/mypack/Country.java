package mypack;

public class Country {

	private int id;
	private String name;
	private HeadofState hos;
	public Country() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Country(String name, HeadofState hos) {
		super();
		this.name = name;
		this.hos = hos;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public HeadofState getHos() {
		return hos;
	}
	public void setHos(HeadofState hos) {
		this.hos = hos;
	}
	
}
