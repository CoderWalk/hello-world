package mypack;

public class HeadofState {

	private int id;
	private String name,title;
	private Country country;
	public HeadofState() {
		super();
		// TODO Auto-generated constructor stub
	}
	public HeadofState(String name, String title) {
		super();
		this.name = name;
		this.title = title;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Country getCountry() {
		return country;
	}
	public void setCountry(Country country) {
		this.country = country;
	}
	
}
