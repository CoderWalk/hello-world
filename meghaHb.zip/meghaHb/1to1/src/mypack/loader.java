package mypack;

import java.util.Scanner;

import org.hibernate.Session;

public class loader {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Session session=MyFactory.getSession();
		System.out.println("enter country id");
		int id=sc.nextInt();
		Country c=(Country)session.get(Country.class,id);
		System.out.println("country is: "+c.getName());
		HeadofState hos1=c.getHos();
		System.out.println("head of state is: "+hos1.getName()+" "+hos1.getTitle());
		System.out.println("enter hos id");
		int d=sc.nextInt();
		HeadofState hos=(HeadofState)session.get(HeadofState.class,d);
		System.out.println("head os state is: "+hos.getName()+" "+hos.getTitle());
		Country c1=hos.getCountry();
		System.out.println("country is: "+c1.getName());
		session.close();
	}

}
