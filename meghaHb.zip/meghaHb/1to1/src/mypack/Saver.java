package mypack;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class Saver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("saving country obj");
		Country c1=new Country("India", new HeadofState("Kovind", "president"));
		Country c2=new Country("Uk", new HeadofState("elizabeth", "queen"));
		Session session=MyFactory.getSession();
		Transaction tx=session.beginTransaction();
		session.save(c1);
		session.save(c2);
		tx.commit();
		session.close();
		System.out.println("successfully saved...");
	}

}
