package mypack;

import java.util.*;

import javax.persistence.EntityManager;

import org.hibernate.Session;

public class Loader {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		Scanner in=new Scanner(System.in);
		System.out.print("Enter EmpId: ");
		int id=in.nextInt();
		
		EntityManager manager=MyFactory.getEntityManager();
		Emp e=(Emp)manager.find(Emp.class,id);
		System.out.println("Emp details:");
		System.out.println(e.getName()+"\t"
				+e.getJob()+"\t"+e.getSalary());
		
		Set<Previlige> pset=e.getPreviliges();
		System.out.println("Previliges availed by the Emp: ");
		for(Previlige p: pset)
		{
			System.out.println(p.getName()+"\t"
					+p.getCost());
		}
		System.out.print("Enter PreviligeId: ");
		id=in.nextInt();
		Previlige pr=(Previlige)manager.find(Previlige.class,id);
		System.out.println("Previlige details:");
		System.out.println(pr.getName()+"\t"
				+pr.getCost());
		Set<Emp> eset=pr.getEmployees();
		System.out.println(
		"The Previlige is availed by following employees: ");
		for(Emp emp: eset)
		{
			System.out.println(emp.getName()+"\t"
					+emp.getJob()+"\t"+emp.getSalary());
		}
		//session is closed
	   	manager.close();
		in.close();
	}
}
